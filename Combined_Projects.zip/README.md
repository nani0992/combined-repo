# 💼 Combined Projects: Expense Tracker & URL Shortener

This repository contains two independent full-stack projects built to demonstrate practical skills in web development, backend APIs, data visualization, and user-centric tools.

## 📊 Project 1: Expense Tracker with Monthly Analytic
### 🔍 Description
A full-featured expense tracking app to log daily expenses, categorize them, and view monthly analytics.

### 🛠 Tech Stack
- Frontend: React.js / HTML, CSS, JS
- Backend: Node.js + Express / Firebase
- Database: MongoDB / Firestore
- Charts: Chart.js / Recharts

## 🔗 Project 2: URL Shortener Service
### 🔍 Description
A service that shortens long URLs into custom, shareable links.

### 🛠 Tech Stack
- Backend: Node.js + Express / Python Flask
- Database: MongoDB / Redis

## 📄 Documentation
See `docs/Combined_Project_Report.docx` for project summaries.
